module.exports = {
    remoteUrl : '<paste your Azure Cosmos DB connection string here',
    
    localUrl: 'mongodb://localhost/meanstacktutorials'
};
